<div class="sidebar">
    <nav class="nav_bar">
        
        <button class="nav_btn" type="button" id="signup">Signup</button>
        <button class="nav_btn" type="button" id="lout">LogOut</button>
        <button class="nav_btn" type="button" id="muser">Manage User's</button>
        <button class="nav_btn" type="button" id="nomini">Nominination's</button>
        <button class="nav_btn" type="button" id="eresult">Election Result</button>
    </nav>
    </div>