<link rel="stylesheet" href="../css/index.css">
<script src="../jsx/jquery-3.7.1.min.js"></script>
<script src="../jsx/index.js"></script>
<div class="sidebar">
    <nav class="nav_bar">
        <button class="nav_btn1" type="button">Postings!!</button>
        <button class="nav_btn" type="button" id="sc">Student Chairman</button>
        <button class="nav_btn" type="button" id="wc">Wise Chairman</button>
        <button class="nav_btn" type="button" id="sec">Secratory</button>
        <button class="nav_btn" type="button" id="tre">Treasurer</button>
    </nav>
    </div>